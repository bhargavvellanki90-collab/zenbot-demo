// Minimal Zenbot demo server (runnable)
const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const stringSimilarity = require('string-similarity');

const app = express();
const app = express();

// ---- Agent basic auth middleware (demo-level protection) ----
function checkAgentAuth(req, res, next) {
  // Allow health, static assets, public endpoints
  const publicPaths = ['/', '/identify', '/verify', '/session/update', '/survey/submit', '/close-case'];
  if (publicPaths.includes(req.path) || req.path.startsWith('/static') || req.path.startsWith('/assets')) {
    return next();
  }
  // Protect /agent endpoints and agent-related paths
  if (req.path.startsWith('/agent') || req.path.includes('agent')) {
    const authHeader = req.headers.authorization || '';
    if (!authHeader.startsWith('Basic ')) {
      res.setHeader('WWW-Authenticate', 'Basic realm="Zenbot Agent Area"');
      return res.status(401).send('Authentication required');
    }
    const base64 = authHeader.split(' ')[1] || '';
    const creds = Buffer.from(base64, 'base64').toString('utf8');
    const [user, pass] = creds.split(':');
    const AGENT_USER = process.env.AGENT_USER || 'agentdemo';
    const AGENT_PASS = process.env.AGENT_PASS || 'agentdemo';
    if (user === AGENT_USER && pass === AGENT_PASS) return next();
    res.setHeader('WWW-Authenticate', 'Basic realm="Zenbot Agent Area"');
    return res.status(403).send('Forbidden');
  }
  return next();
}

app.use(checkAgentAuth);

const port = process.env.PORT || 3000;
app.use(bodyParser.json());
app.use(express.static('.'));

const DATA_DIR = path.join(__dirname, 'data');
let USERS = [];
let CASE_PHRASES = [];
try{ USERS = JSON.parse(fs.readFileSync(path.join(DATA_DIR,'users.json'),'utf8')); }catch(e){}
try{ const cp = JSON.parse(fs.readFileSync(path.join(DATA_DIR,'cases_500.json'),'utf8')); if(Array.isArray(cp) && cp.length){ if(typeof cp[0]==='string') CASE_PHRASES = cp.map(t=>({text:t.toLowerCase(),intent:'password_reset'})); else if(cp[0].customer_utterance) CASE_PHRASES = cp.map(p=>({text:(p.customer_utterance||'').toLowerCase(), intent: p.intent||'password_reset'})); } }catch(e){}

const TICKETS=[], SUMMARIES=[], SURVEYS=[], SESSION_TRACKER={}, verificationAttempts={};

function inferCountryFromPhone(phone){ if(!phone) return null; const map={'+91':'India','+1':'USA/Canada','+44':'UK'}; const p=(phone||'').replace(/\\s|\\-|\\(|\\)/g,''); for(const k of Object.keys(map)) if(p.startsWith(k)) return map[k]; return null; }
function createTicketId(){ const chars='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'; let id=''; for(let i=0;i<6;i++) id+=chars[Math.floor(Math.random()*chars.length)]; return id; }
function createTicketRecord({session,user=null,reason='verification',visibleToCustomer=false,meta={}}){ const ticketId=createTicketId(); const createdAt=new Date().toISOString(); const rec={ticketId,session,createdAt,visibleToCustomer,reason,user:user?{id:user.User_ID,firstName:user.First_Name,lastName:user.Last_Name,email:user.Email}:null,meta}; if(SESSION_TRACKER[session]) rec.origin=SESSION_TRACKER[session]; TICKETS.push(rec); console.log('[TICKET-CREATED]',JSON.stringify(rec)); return rec; }
function findTicket(id){ return TICKETS.find(t=>t.ticketId===id); }
function verifyUserRecord({firstName,lastName,email,phone}){ if(!firstName && !lastName && !email && !phone) return {ok:false,reason:'missing_all'}; const match = USERS.find(u=>{ const firstOk = firstName? u.First_Name.toLowerCase()===firstName.toLowerCase():true; const lastOk = lastName? u.Last_Name.toLowerCase()===lastName.toLowerCase():true; const emailOk = email? u.Email.toLowerCase()===email.toLowerCase():true; const phoneOk = phone? (u.Contact_Number.endsWith(phone)||u.Contact_Number===phone):true; return firstOk && lastOk && emailOk && phoneOk; }); if(match) return {ok:true,user:match}; return {ok:false,reason:'no_match'} }

app.get('/', (req,res)=> res.sendFile(path.join(__dirname,'landing.html')));

app.post('/identify',(req,res)=>{
  const text=(req.body.utterance||'').trim();
  if(!text) return res.status(400).json({error:'utterance required'});
  const rules=[['forgot_password',['forgot','reset password','reset my password']],['expired_link',['expired','token expired']],['didnt_receive_link',['did not receive','didn\\'t receive','no email']]];
  for(const r of rules){ for(const k of r[1]) if(text.toLowerCase().includes(k)) return res.json({intent:r[0],confidence:0.9,method:'rule'}); }
  // fuzzy
  if(CASE_PHRASES.length){
    const best=stringSimilarity.findBestMatch(text.toLowerCase(), CASE_PHRASES.map(p=>p.text));
    if(best.bestMatch.rating>0.6) return res.json({intent: CASE_PHRASES[best.bestMatchIndex].intent, confidence: best.bestMatch.rating, method:'fuzzy'});
  }
  const suggestions=[{intent:'forgot_password',label:'I forgot my password (send reset link)'},{intent:'didnt_receive_link',label:"I didn't receive the reset email"}];
  return res.json({intent:'unknown',confidence:0,method:'fallback',suggestions});
});

app.post('/session/update',(req,res)=>{
  const {session_id,timezone,locale,lat,lon,phone} = req.body || {};
  if(!session_id) return res.status(400).json({error:'session_id required'});
  const country = inferCountryFromPhone(phone);
  const rec = {sessionId:session_id,timezone:timezone||null,locale:locale||null,country,lat:lat||null,lon:lon||null,localTime: timezone? new Date().toLocaleString('en-US',{timeZone:timezone}): new Date().toISOString(), updatedAt: new Date().toISOString()};
  SESSION_TRACKER[session_id]=rec;
  console.log('[SESSION-UPDATE]',JSON.stringify(rec));
  res.json({status:'ok',session:rec});
});

app.post('/verify',(req,res)=>{
  const session = req.body.session_id || 'demo-session';
  const { firstName, lastName, email, phone } = req.body || {};
  const result = verifyUserRecord({firstName,lastName,email,phone});
  if(result.ok){
    verificationAttempts[session]=0;
    const user = result.user;
    const ticket = createTicketRecord({session,user,reason:'verification_success',visibleToCustomer:true,meta:{message:'Verified demo'}});
    return res.json({status:'verified',message:`Verified ${user.First_Name} ${user.Last_Name}.`,user:{id:user.User_ID,firstName:user.First_Name,lastName:user.Last_Name,email:user.Email},ticket:{id:ticket.ticketId,createdAt:ticket.createdAt}});
  }
  verificationAttempts[session] = (verificationAttempts[session]||0)+1;
  const attempts = verificationAttempts[session];
  if(attempts<3){
    createTicketRecord({session,user:null,reason:'verification_retry',visibleToCustomer:false,meta:{attempts}});
    return res.json({status:'retry',attempts,message:`Verification failed (attempt ${attempts}). Please retry.`,ticketVisible:false});
  } else {
    createTicketRecord({session,user:null,reason:'verification_escalate',visibleToCustomer:false,meta:{attempts}});
    return res.json({status:'escalate',message:'Verification failed multiple times and has been routed to a human agent for review.',ticketVisible:false,agentNotify:{queue:'L2-Security'}});
  }
});

app.get('/agent/tickets',(req,res)=> res.json({tickets:TICKETS}));
app.post('/agent/notes',(req,res)=>{ const {ticketId,agentId,notes,markResolved} = req.body || {}; const t=findTicket(ticketId); if(!t) return res.status(404).json({error:'ticket not found'}); if(markResolved){ // simulate survey creation
    const surveyToken = ticketId + '-' + Math.floor(Math.random()*9000+1000);
    const surveyLink = `/survey/form/${surveyToken}`;
    SURVEYS.push({ticketId,surveyToken,surveyLink,createdAt:new Date().toISOString(),rating:null,feedback:null});
    return res.json({status:'resolved',ticketId,surveyLink,surveyToken});
  } return res.json({status:'note_saved',ticketId}); });

app.post('/close-case',(req,res)=>{ const {ticketId,session,resolutionText,resolvedBy} = req.body || {}; if(!ticketId||!resolvedBy) return res.status(400).json({error:'ticketId and resolvedBy required'}); const t=findTicket(ticketId); if(!t) return res.status(404).json({error:'ticket not found'}); // finalize
  const surveyToken = ticketId + '-' + Math.floor(Math.random()*9000+1000);
  const surveyLink = `/survey/form/${surveyToken}`; SURVEYS.push({ticketId,surveyToken,surveyLink,createdAt:new Date().toISOString(),rating:null,feedback:null});
  return res.json({status:'closed',ticketId,resolvedAt:new Date().toISOString(),surveySentToCustomer: resolvedBy==='bot', survey: resolvedBy==='bot'?{surveyLink,surveyToken}:{message:'Survey to be sent by agent (demo)'}});
});

app.post('/survey/submit',(req,res)=>{ const {surveyToken,ticketId,rating,feedback} = req.body || {}; if(!surveyToken||!ticketId||!rating) return res.status(400).json({error:'missing fields'}); const s = SURVEYS.find(x=>x.surveyToken===surveyToken && x.ticketId===ticketId); if(!s) return res.status(404).json({error:'survey not found'}); s.rating=rating; s.feedback=feedback||''; s.submittedAt=new Date().toISOString(); console.log('[SURVEY-SUBMITTED]',JSON.stringify(s)); return res.json({status:'ok'}); });

app.get('/debug/state',(req,res)=> res.json({tickets:TICKETS,surveys:SURVEYS,sessions:SESSION_TRACKER}));

app.listen(port,()=>console.log(`Zenbot demo server running at http://localhost:${port}`));