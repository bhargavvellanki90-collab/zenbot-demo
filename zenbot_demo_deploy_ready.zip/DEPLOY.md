# Deploying Zenbot Demo - One-click options (non-technical friendly)

This repository includes ready-made deployment artifacts for Cloud Run, Heroku, and Railway.
Follow the simple steps below to get a public demo URL you can click in front of leaders.

## Option A — One-click to Heroku (Easiest for non-technical users)
1. Click the Deploy to Heroku button (replace the URL with your repo URL if needed):
   - Create a GitHub repository (upload the project files)
   - Open: https://dashboard.heroku.com/new?template=https://github.com/YOUR_ORG/YOUR_REPO
   - Follow Heroku prompts (use default settings). This will build and deploy the app and provide a public HTTPS URL.
2. Default demo agent credentials (for agent dashboard access):
   - Username: **agentdemo**
   - Password: **agentdemo**
   (You can change these environment variables in Heroku app settings: `AGENT_USER`, `AGENT_PASS`)

## Option B — Cloud Run via GitHub Actions (recommended for secure demos)
1. Push repo to GitHub main branch.
2. Add GitHub Secrets in your repo settings: `GCP_PROJECT`, `GCP_SA_KEY` (JSON), `GCP_REGION` (optional).
3. On push to `main`, the workflow `cloud-run.yml` will build and deploy and give you a public HTTPS URL in Cloud Run Console.

## Option C — Railway
1. Create a Railway account and new project, connect GitHub repo, and deploy.
2. Set env vars `AGENT_USER` and `AGENT_PASS` in Railway project settings if you want to change defaults.

## Local testing (if you prefer not to deploy publicly)
1. Install Node: https://nodejs.org/
2. Open terminal in project directory, run:
   ```bash
   npm install
   npm start
   ```
3. Open http://localhost:3000 in your browser.

---

If you'd like, I can deploy the demo for you to a Cloud Run or Heroku app and provide the clickable public URL — for that I will need either:
- Access to a GitHub repo where I can push code and you click the Heroku button; OR
- Deployment permissions/credentials for your cloud account (I will give exact steps for adding those securely).

Tell me which option you prefer and I'll assist step-by-step.
