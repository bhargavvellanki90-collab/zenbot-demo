
# Zenbot - Recommendations & Next Steps

This document summarizes the prioritized recommendations to move Zenbot from demo -> production and talking points for leaders.

## Must-haves (short-term, high priority)
1. **Persistent Storage**
   - Replace in-memory stores with Postgres (or Redis for short-lived). Store tickets, summaries, surveys, sessions.
2. **Agent Authentication & RBAC**
   - Protect `/agent/*` endpoints with SSO or at least basic auth for demo. Implement role-based access.
3. **PII Handling**
   - Mask emails/phone in customer-facing UIs and logs. Store full PII only in secured DB with limited access.
4. **ITSM Integration**
   - Integrate with ServiceNow/Zendesk to sync tickets and agent workflows.
5. **Secure Survey Delivery**
   - Issue signed, expiring survey links; send via email/SMS using transactional provider.

## Medium-term (impactful improvements)
1. **Intent Model**
   - Fine-tune a DistilBERT (or similar) model on the 500+ labeled utterances. Host on HF or self-host inference.
2. **NLU Evaluation Pipeline**
   - Implement metrics: per-intent precision, recall, confusion matrix. Add automated retraining pipeline.
3. **Logging & Monitoring**
   - Structured logs, Sentry for errors, Prometheus/Grafana for metrics (throughput, success rates, escalations).
4. **Rate Limiting & Fraud Detection**
   - Monitor repeated failed verification attempts; block abusive sessions/IPs.

## Nice-to-haves (future)
1. **ITSM & Contact Center**
   - Bi-directional ticket sync, agent workspace integration (Twilio Flex/Zendesk).
2. **Localization & Timezone-aware routing**
   - Route to timezone-local agent pools and localized messages.
3. **Map view in Agent Dashboard**
   - Show user geolocation (with consent) for routing insights.
4. **Export & Reporting**
   - CSV/Excel export of SUMMARIES for leadership review.

## Demo preparation checklist (before leader presentation)
1. Replace `data/users.json` and `data/cases_500.json` with real files.
2. Run `npm install` and `npm start` locally; verify key flows:
   - Auto-resolve happy path (ticket + survey)
   - 3x invalid verify -> escalate -> agent resolve -> survey
   - Intent suggestions and voice input
3. Mask any real PII while screensharing.
4. Prepare the server terminal logs to show audit messages: `[TICKET-CREATED]`, `[SUMMARY-UPDATE]`, `[SURVEY-CREATED]`, `[SURVEY-SUBMITTED]`.
5. Optional: enable simple basic auth on agent endpoints for demo.

## Metrics to present to leaders
- Expected bot containment / deflection (% of password-reset cases handled by bot)
- Average resolution time (bot vs agent)
- Escalation rate (per 1k requests)
- CSAT (survey results) and NPS signals

## Security & Compliance notes
- Require explicit consent for geolocation.
- Encrypt sensitive data at rest and in transit.
- Implement data retention and deletion policies.
- Keep agent UI behind corporate SSO and audit access logs.

## Next immediate tasks I can do for you
1. Patch demo to use SQLite for persistence (keeps demo simple and persistent across restarts).
2. Add basic auth for agent endpoints (demo-level protection).
3. Rebuild the package with your real `users.json` & `cases_500.json` if you upload them.
4. Create Cloud Run / Railway manifest for one-click deploy.
5. Create a short 5-slide PPT summarizing architecture and demo script.

--- End of recommendations
