

---

Agent demo credentials (demo-only):
- AGENT_USER=agentdemo
- AGENT_PASS=agentdemo

See DEPLOY.md for one-click deploy instructions.
